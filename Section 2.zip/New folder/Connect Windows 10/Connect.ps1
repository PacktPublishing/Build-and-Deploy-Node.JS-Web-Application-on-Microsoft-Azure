﻿
Set-ExecutionPolicy  unrestricted

### Copy File Share connection string below

