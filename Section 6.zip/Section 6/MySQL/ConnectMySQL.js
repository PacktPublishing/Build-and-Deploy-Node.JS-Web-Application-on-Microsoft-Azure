const mysql = require('mysql');

var config =
{
    host: 'hostname.mysql.database.azure.com',
    user: 'name@server',
    password: 'password',
    database: 'mysql',
    port: 3306,
    ssl: true
};

const conn = new mysql.createConnection(config);

conn.connect(
    function (err) { 
    if (err) { 
        console.log("!!! Cannot connect !!! Error:");
        throw err;
    }
    else
    {
       console.log("Connection established.");
         
    }   
});

    
