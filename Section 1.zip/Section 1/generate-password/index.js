var http = require('http');
var server = http.createServer(function(request, response) {

    console.log('Your password is:');
     var generator = require('generate-password');
     var password = generator.generate({
      length: 10,
     numbers: true
     });
    'uEyMTw32v9'
    //console.log(password);
    response.writeHead(200, {"Content-Type": "text/plain"});
    
    //response.end("Hello World!");
    response.end('Hello, Your Password is: ' + password);
});
var port = process.env.PORT || 1337;
server.listen(port);
console.log("Server running at http://localhost:%d", port);
CVVC
